﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Sports_Assignment3.Models;

namespace Sports_Assignment3.Data
{
    public class Sports_Assignment3Context : DbContext
    {
        public Sports_Assignment3Context (DbContextOptions<Sports_Assignment3Context> options)
            : base(options)
        {
        }

        public DbSet<Sports_Assignment3.Models.Hockey> Hockey { get; set; } = default!;
    }
}
