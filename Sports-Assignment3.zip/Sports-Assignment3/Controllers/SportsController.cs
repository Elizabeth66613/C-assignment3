﻿using Microsoft.AspNetCore.Mvc;

namespace Sports_Assignment3.Controllers
{
	public class SportsController : Controller
	{
		//Get Sports
		public IActionResult Index()
		{
			return View();
		}

		//Get AboutUs
		public IActionResult AboutUs()
		{
			return View();
		}

		//Get Contact
		public IActionResult Contact()
		{
			return View();
		}
	}
}
