﻿using System.ComponentModel.DataAnnotations;

namespace Sports_Assignment3.Models
{
    public class Hockey
    {
        //by default primary key is id or anynameid and we don't have any id that's why we added a key
        [Key]
        public string? PlayerName { get; set; }

        //required=>cannot be null
        [Required]
        public int PlayerAge { get; set; }

        
        public int PlayerHeight { get; set; }

    }
}
