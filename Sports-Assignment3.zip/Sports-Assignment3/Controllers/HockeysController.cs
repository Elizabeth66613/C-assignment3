﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Sports_Assignment3.Data;
using Sports_Assignment3.Models;

namespace Sports_Assignment3.Controllers
{
    public class HockeysController : Controller
    {
        private readonly Sports_Assignment3Context _context;

        public HockeysController(Sports_Assignment3Context context)
        {
            _context = context;
        }

        // GET: Hockeys
        public async Task<IActionResult> Index()
        {
            return View(await _context.Hockey.ToListAsync());
        }

        // GET: Hockeys/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var hockey = await _context.Hockey
                .FirstOrDefaultAsync(m => m.PlayerName == id);
            if (hockey == null)
            {
                return NotFound();
            }

            return View(hockey);
        }

        // GET: Hockeys/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Hockeys/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PlayerName,PlayerAge,PlayerHeight")] Hockey hockey)
        {
            if (ModelState.IsValid)
            {
                _context.Add(hockey);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(hockey);
        }

        // GET: Hockeys/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var hockey = await _context.Hockey.FindAsync(id);
            if (hockey == null)
            {
                return NotFound();
            }
            return View(hockey);
        }

        // POST: Hockeys/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("PlayerName,PlayerAge,PlayerHeight")] Hockey hockey)
        {
            if (id != hockey.PlayerName)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(hockey);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!HockeyExists(hockey.PlayerName))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(hockey);
        }

        // GET: Hockeys/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var hockey = await _context.Hockey
                .FirstOrDefaultAsync(m => m.PlayerName == id);
            if (hockey == null)
            {
                return NotFound();
            }

            return View(hockey);
        }

        // POST: Hockeys/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var hockey = await _context.Hockey.FindAsync(id);
            if (hockey != null)
            {
                _context.Hockey.Remove(hockey);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool HockeyExists(string id)
        {
            return _context.Hockey.Any(e => e.PlayerName == id);
        }
    }
}
